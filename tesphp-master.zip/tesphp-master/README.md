# heroku-static-template
Starter files to create a static site masquerading as php on Heroku

Based on info from:
1) https://medium.com/@winnieliang/how-to-run-a-simple-html-css-javascript-application-on-heroku-4e664c541b0b
2) https://stackoverflow.com/questions/23564500/is-it-possible-to-push-a-index-html-to-heroku

To deploy, from CLI:
1) `heroku apps:create example`
2) `git push heroku master`  or `git push heroku branchname:master`
